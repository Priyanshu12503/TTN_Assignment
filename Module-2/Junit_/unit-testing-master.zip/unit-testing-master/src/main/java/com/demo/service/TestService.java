package com.demo.service;

public class TestService {
    public int test() {
        return 1;
    }
}
